<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE helpset PUBLIC "-//Sun Microsystems Inc.//DTD JavaHelp HelpSet Version 2.0//EN" "http://java.sun.com/products/javahelp/helpset_2_0.dtd">
<helpset version="2.0">
    <title>test</title>
    <maps>
        <homeID>test</homeID>
        <mapref location="map.jhm"/>
    </maps>
    <presentation>
        <name>main</name>
        <title>test</title>
    </presentation>
</helpset>
